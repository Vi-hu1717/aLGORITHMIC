import jwt from "jsonwebtoken";
import { cookies } from "next/headers";
import type { Role } from "@prisma/client";

const JWT_SECRET = process.env.JWT_SECRET;
const EXPIRES_IN = Number(process.env.JWT_EXPIRES_IN_SECONDS ?? 28800); // 8h

if (!JWT_SECRET) {
  // Fail loudly at boot rather than silently signing with `undefined`.
  throw new Error(
    "JWT_SECRET is not set. Copy .env.example to .env and set a strong secret."
  );
}

export interface SessionPayload {
  userId: string;
  role: Role;
  // For students: student.id. For admins: admin.id. Lets handlers avoid an
  // extra join on every request.
  profileId: string;
  // Human-readable label for audit logs / UI, never used for authorization.
  displayName: string;
}

const COOKIE_NAME = "rljit_session";

export function signSession(payload: SessionPayload): string {
  return jwt.sign(payload, JWT_SECRET as string, { expiresIn: EXPIRES_IN });
}

export function verifySession(token: string): SessionPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET as string) as SessionPayload;
  } catch {
    return null;
  }
}

/** Set the session cookie on a response. httpOnly + Secure + SameSite=strict
 *  so the token is never reachable from JS and never sent cross-site. */
export function buildSessionCookie(token: string) {
  return {
    name: COOKIE_NAME,
    value: token,
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict" as const,
    path: "/",
    maxAge: EXPIRES_IN,
  };
}

export function clearSessionCookie() {
  return {
    name: COOKIE_NAME,
    value: "",
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict" as const,
    path: "/",
    maxAge: 0,
  };
}

/** Read + verify the session from the incoming request's cookies.
 *  Use in Server Components / Route Handlers. `cookies()` is async as of
 *  Next.js 15, so this must be awaited by callers. */
export async function getSessionFromCookies(): Promise<SessionPayload | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifySession(token);
}

export const SESSION_COOKIE_NAME = COOKIE_NAME;
