import { z } from "zod";

export const studentLoginSchema = z.object({
  usn: z
    .string()
    .trim()
    .min(3, "USN is required")
    .max(20)
    .transform((s) => s.toUpperCase()),
  password: z.string().min(1, "Password is required").max(200),
  // Optional: an event access code, required only when logging in to enter
  // a specific event rather than the general student dashboard.
  eventAccessCode: z.string().trim().max(50).optional(),
});
export type StudentLoginInput = z.infer<typeof studentLoginSchema>;

export const adminLoginSchema = z.object({
  email: z.string().trim().toLowerCase().email("Enter a valid email"),
  password: z.string().min(1, "Password is required").max(200),
});
export type AdminLoginInput = z.infer<typeof adminLoginSchema>;
