import bcrypt from "bcryptjs";

const SALT_ROUNDS = Number(process.env.BCRYPT_SALT_ROUNDS ?? 12);

/** Hash a plaintext password (or access code) before storing it. */
export async function hashSecret(plain: string): Promise<string> {
  return bcrypt.hash(plain, SALT_ROUNDS);
}

/** Compare a plaintext value against a stored bcrypt hash. Always use this —
 *  never compare hashes with `===`, and never log the plaintext value. */
export async function verifySecret(
  plain: string,
  hash: string
): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}
