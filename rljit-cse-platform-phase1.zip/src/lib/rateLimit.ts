/**
 * Minimal token-bucket rate limiter, keyed by an identifier (IP, or
 * IP+userId). Good enough for a single-instance deployment; if the app is
 * ever horizontally scaled, swap this for a Redis-backed limiter (e.g.
 * `@upstash/ratelimit`) without changing the call sites below.
 */

interface Bucket {
  tokens: number;
  lastRefill: number;
}

const buckets = new Map<string, Bucket>();

export interface RateLimitOptions {
  /** Max requests allowed within `windowMs`. */
  limit: number;
  windowMs: number;
}

export function checkRateLimit(
  key: string,
  { limit, windowMs }: RateLimitOptions
): { allowed: boolean; retryAfterMs: number } {
  const now = Date.now();
  const bucket = buckets.get(key) ?? { tokens: limit, lastRefill: now };

  const elapsed = now - bucket.lastRefill;
  const refillAmount = (elapsed / windowMs) * limit;
  bucket.tokens = Math.min(limit, bucket.tokens + refillAmount);
  bucket.lastRefill = now;

  if (bucket.tokens >= 1) {
    bucket.tokens -= 1;
    buckets.set(key, bucket);
    return { allowed: true, retryAfterMs: 0 };
  }

  buckets.set(key, bucket);
  const msPerToken = windowMs / limit;
  const retryAfterMs = Math.ceil((1 - bucket.tokens) * msPerToken);
  return { allowed: false, retryAfterMs };
}

// Sensible defaults for the endpoints that need protection.
export const LOGIN_RATE_LIMIT: RateLimitOptions = {
  limit: 5,
  windowMs: 60_000, // 5 attempts per minute per key
};

export const AUTOSAVE_RATE_LIMIT: RateLimitOptions = {
  limit: 30,
  windowMs: 60_000,
};
