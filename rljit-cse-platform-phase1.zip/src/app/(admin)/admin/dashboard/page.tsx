import { getSessionFromCookies } from "@/lib/auth";
import { db } from "@/lib/db";

export default async function AdminDashboardPage() {
  const session = await getSessionFromCookies();
  const admin = session
    ? await db.admin.findUnique({ where: { id: session.profileId } })
    : null;

  return (
    <main className="mx-auto max-w-2xl px-6 py-16">
      <h1 className="font-display text-2xl font-semibold text-white">
        Welcome{admin ? `, ${admin.name}` : ""}
      </h1>
      <p className="mt-2 text-sm text-slate-400">{admin?.department}</p>
      <div className="mt-8 rounded-md border border-navy-700 bg-navy-900/60 p-6 text-sm text-slate-400">
        Stat cards and event management are built in Phase 2. Authentication
        and role-based access are working — this page confirms your admin
        session.
      </div>
    </main>
  );
}
