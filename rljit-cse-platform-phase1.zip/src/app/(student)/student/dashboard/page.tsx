import { getSessionFromCookies } from "@/lib/auth";
import { db } from "@/lib/db";

export default async function StudentDashboardPage() {
  const session = await getSessionFromCookies();
  const student = session
    ? await db.student.findUnique({ where: { id: session.profileId } })
    : null;

  return (
    <main className="mx-auto max-w-2xl px-6 py-16">
      <h1 className="font-display text-2xl font-semibold text-white">
        Welcome{student ? `, ${student.name}` : ""}
      </h1>
      <p className="mt-2 text-sm text-slate-400">
        USN {student?.usn} · Semester {student?.semester} · Section{" "}
        {student?.section}
      </p>
      <div className="mt-8 rounded-md border border-navy-700 bg-navy-900/60 p-6 text-sm text-slate-400">
        Event details, instructions, and the Start Test button are built in
        Phase 4 (Student Test Interface). Authentication is working — this
        page confirms your session and role.
      </div>
    </main>
  );
}
