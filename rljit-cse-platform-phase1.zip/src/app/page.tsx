import Link from "next/link";

export default function LandingPage() {
  return (
    <main className="relative min-h-screen overflow-hidden">
      <BackgroundLattice />

      <div className="relative z-10 mx-auto flex min-h-screen max-w-6xl flex-col px-6 py-10 lg:px-10">
        <header className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-sm border border-gold-500/60 font-display text-lg font-semibold text-gold-400">
              RL
            </div>
            <div className="leading-tight">
              <p className="font-display text-sm font-medium tracking-wide text-slate-200">
                R. L. Jalappa Institute of Technology
              </p>
              <p className="text-xs text-slate-400">
                Department of Computer Science &amp; Engineering
              </p>
            </div>
          </div>
        </header>

        <div className="mt-16 grid flex-1 gap-16 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
          <section>
            <h1 className="font-display text-4xl font-semibold leading-[1.1] text-white sm:text-5xl">
              CSE Algorithmic Challenge
            </h1>
            <p className="mt-4 max-w-md text-slate-300">
              A timed, proctored assessment covering algorithmic reasoning,
              aptitude, and hands-on programming — run and monitored live by
              the CSE faculty.
            </p>

            <dl className="mt-10 grid max-w-md grid-cols-2 gap-x-6 gap-y-5 border-t border-navy-700 pt-6 text-sm">
              <Detail label="Eligible students" value="3rd & 5th Sem CSE" />
              <Detail label="Venue" value="ACIL Lab" />
              <Detail label="Date" value="10 September 2026" />
              <Detail label="Time" value="1:30 PM – 4:00 PM" />
            </dl>
          </section>

          <section className="grid gap-4">
            <RoleCard
              href="/student/login"
              eyebrow="Participant"
              title="Student"
              description="Log in with your USN to view your event, read instructions, and start your test."
            />
            <RoleCard
              href="/admin/login"
              eyebrow="Organizer"
              title="Faculty / Admin"
              description="Create events, manage questions and students, monitor attempts live, and publish results."
            />
          </section>
        </div>

        <footer className="mt-16 flex items-center justify-between border-t border-navy-700 pt-5 text-xs text-slate-500">
          <span>RLJIT CSE Algorithmic Challenge Platform</span>
          <span className="font-mono">v0.1.0 · Phase 1</span>
        </footer>
      </div>
    </main>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-slate-500">{label}</dt>
      <dd className="mt-1 font-medium text-slate-200">{value}</dd>
    </div>
  );
}

function RoleCard({
  href,
  eyebrow,
  title,
  description,
}: {
  href: string;
  eyebrow: string;
  title: string;
  description: string;
}) {
  return (
    <Link
      href={href}
      className="group relative overflow-hidden rounded-md border border-navy-700 bg-navy-900/60 p-6 transition-colors hover:border-gold-500/70"
    >
      <p className="text-xs font-medium text-gold-400">{eyebrow}</p>
      <h2 className="mt-2 font-display text-2xl font-semibold text-white">
        {title}
      </h2>
      <p className="mt-2 max-w-xs text-sm text-slate-400">{description}</p>
      <span className="mt-5 inline-flex items-center text-sm font-medium text-gold-400">
        Continue
      </span>
    </Link>
  );
}

/** Subtle circuit/graph lattice — nods to algorithms & CSE without leaning
 *  on a stock gradient or particle-field cliché. Decorative, aria-hidden. */
function BackgroundLattice() {
  return (
    <svg
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 h-full w-full opacity-[0.15]"
      viewBox="0 0 1200 800"
      preserveAspectRatio="xMidYMid slice"
    >
      <defs>
        <pattern id="dots" width="60" height="60" patternUnits="userSpaceOnUse">
          <circle cx="2" cy="2" r="1.4" fill="#D4A017" />
        </pattern>
      </defs>
      <rect width="1200" height="800" fill="url(#dots)" />
      <g stroke="#3868AF" strokeWidth="1">
        <path d="M0 120 L300 220 L620 90 L1000 260 L1200 180" fill="none" />
        <path d="M0 620 L260 520 L560 660 L860 480 L1200 560" fill="none" />
        <path d="M180 0 L340 340 L120 700" fill="none" />
        <path d="M980 0 L860 300 L1080 620" fill="none" />
      </g>
    </svg>
  );
}
