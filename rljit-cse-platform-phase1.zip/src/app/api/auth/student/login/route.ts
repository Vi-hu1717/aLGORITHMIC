import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { verifySecret } from "@/lib/hash";
import { signSession, buildSessionCookie } from "@/lib/auth";
import { studentLoginSchema } from "@/lib/validation";
import { checkRateLimit, LOGIN_RATE_LIMIT } from "@/lib/rateLimit";
import { writeAuditLog, ipFromRequest } from "@/lib/audit";

export async function POST(req: Request) {
  const ip = ipFromRequest(req) ?? "unknown";

  const rl = checkRateLimit(`student-login:${ip}`, LOGIN_RATE_LIMIT);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: "Too many login attempts. Please wait and try again." },
      { status: 429, headers: { "Retry-After": String(Math.ceil(rl.retryAfterMs / 1000)) } }
    );
  }

  const body = await req.json().catch(() => null);
  const parsed = studentLoginSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid input", details: parsed.error.flatten() },
      { status: 400 }
    );
  }
  const { usn, password } = parsed.data;

  // Generic error message for both "no such USN" and "wrong password" so we
  // never leak which USNs exist in the system.
  const genericError = NextResponse.json(
    { error: "Invalid USN or password." },
    { status: 401 }
  );

  const student = await db.student.findUnique({
    where: { usn },
    include: { user: true },
  });

  if (!student || !student.user.isActive) {
    return genericError;
  }

  const passwordOk = await verifySecret(password, student.user.passwordHash);
  if (!passwordOk) {
    return genericError;
  }

  const token = signSession({
    userId: student.user.id,
    role: "STUDENT",
    profileId: student.id,
    displayName: student.name,
  });

  const res = NextResponse.json({
    ok: true,
    student: {
      id: student.id,
      usn: student.usn,
      name: student.name,
      semester: student.semester,
      section: student.section,
    },
  });

  const cookie = buildSessionCookie(token);
  res.cookies.set(cookie.name, cookie.value, cookie);

  await writeAuditLog({
    actorId: student.user.id,
    action: "STUDENT_LOGIN",
    targetType: "student",
    targetId: student.id,
    ipAddress: ip,
  });

  return res;
}
