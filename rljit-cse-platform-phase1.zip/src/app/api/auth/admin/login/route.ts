import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { verifySecret } from "@/lib/hash";
import { signSession, buildSessionCookie } from "@/lib/auth";
import { adminLoginSchema } from "@/lib/validation";
import { checkRateLimit, LOGIN_RATE_LIMIT } from "@/lib/rateLimit";
import { writeAuditLog, ipFromRequest } from "@/lib/audit";

export async function POST(req: Request) {
  const ip = ipFromRequest(req) ?? "unknown";

  const rl = checkRateLimit(`admin-login:${ip}`, LOGIN_RATE_LIMIT);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: "Too many login attempts. Please wait and try again." },
      { status: 429, headers: { "Retry-After": String(Math.ceil(rl.retryAfterMs / 1000)) } }
    );
  }

  const body = await req.json().catch(() => null);
  const parsed = adminLoginSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid input", details: parsed.error.flatten() },
      { status: 400 }
    );
  }
  const { email, password } = parsed.data;

  const genericError = NextResponse.json(
    { error: "Invalid email or password." },
    { status: 401 }
  );

  const user = await db.user.findUnique({
    where: { email },
    include: { admin: true },
  });

  if (!user || !user.isActive || user.role !== "ADMIN" || !user.admin) {
    return genericError;
  }

  const passwordOk = await verifySecret(password, user.passwordHash);
  if (!passwordOk) {
    return genericError;
  }

  const token = signSession({
    userId: user.id,
    role: "ADMIN",
    profileId: user.admin.id,
    displayName: user.admin.name,
  });

  const res = NextResponse.json({
    ok: true,
    admin: {
      id: user.admin.id,
      name: user.admin.name,
      department: user.admin.department,
      email: user.email,
    },
  });

  const cookie = buildSessionCookie(token);
  res.cookies.set(cookie.name, cookie.value, cookie);

  await writeAuditLog({
    actorId: user.id,
    action: "ADMIN_LOGIN",
    targetType: "admin",
    targetId: user.admin.id,
    ipAddress: ip,
  });

  return res;
}
