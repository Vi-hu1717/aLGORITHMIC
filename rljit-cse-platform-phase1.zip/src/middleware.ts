import { NextRequest, NextResponse } from "next/server";
import { verifySession, SESSION_COOKIE_NAME } from "@/lib/auth";

// NOTE: middleware runs on the Edge runtime, so it only does a lightweight
// JWT signature check (no DB call). Every route handler still re-verifies
// ownership/role server-side — this is defense-in-depth, not the only check.

const PUBLIC_PATHS = [
  "/",
  "/student/login",
  "/admin/login",
  "/api/auth/student/login",
  "/api/auth/admin/login",
  "/api/auth/logout",
];

function isPublic(pathname: string) {
  return (
    PUBLIC_PATHS.includes(pathname) ||
    pathname.startsWith("/_next") ||
    pathname.startsWith("/favicon")
  );
}

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  if (isPublic(pathname)) {
    return NextResponse.next();
  }

  const token = req.cookies.get(SESSION_COOKIE_NAME)?.value;
  const session = token ? verifySession(token) : null;

  const isAdminArea = pathname.startsWith("/admin") || pathname.startsWith("/api/admin");
  const isStudentArea = pathname.startsWith("/student") || pathname.startsWith("/api/student");

  if (isAdminArea) {
    if (!session || session.role !== "ADMIN") {
      return redirectOrDeny(req, "/admin/login");
    }
  }

  if (isStudentArea) {
    if (!session || session.role !== "STUDENT") {
      return redirectOrDeny(req, "/student/login");
    }
  }

  // Generic /api/* routes not under /api/admin or /api/student (e.g. shared
  // resources) must still be authenticated; individual handlers enforce
  // fine-grained authorization.
  if (pathname.startsWith("/api") && !session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  return NextResponse.next();
}

function redirectOrDeny(req: NextRequest, loginPath: string) {
  if (req.nextUrl.pathname.startsWith("/api")) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const url = req.nextUrl.clone();
  url.pathname = loginPath;
  url.searchParams.set("redirectedFrom", req.nextUrl.pathname);
  return NextResponse.redirect(url);
}

export const config = {
  matcher: [
    /*
     * Match everything except static files, so we cover both pages and
     * API routes with one middleware.
     */
    "/((?!_next/static|_next/image|favicon.ico).*)",
  ],
};
