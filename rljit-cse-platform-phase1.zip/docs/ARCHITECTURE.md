# RLJIT CSE Algorithmic Challenge Platform — Architecture

## 1. System Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                         CLIENT (Browser)                             │
│   Student UI (Next.js/React)     Admin UI (Next.js/React)            │
│   - Login, Test runner, Timer    - Dashboard, Event/Q mgmt, Live     │
└───────────────┬───────────────────────────────┬──────────────────────┘
                │ HTTPS (JWT in httpOnly cookie) │
┌───────────────▼───────────────────────────────▼──────────────────────┐
│                     MAIN APP SERVER (Next.js)                        │
│  - API routes (REST, under /api)                                     │
│  - Auth (credentials, bcrypt, JWT sessions, role-based middleware)   │
│  - Business logic: events, questions, attempts, scoring (non-code)   │
│  - Server-Sent Events (SSE) endpoint for live monitoring             │
│  - NEVER executes student-submitted code                             │
└───────────────┬───────────────────────────────┬──────────────────────┘
                │ SQL (Prisma)                   │ HTTPS (internal, auth'd)
┌───────────────▼───────────────┐   ┌────────────▼───────────────────────┐
│         PostgreSQL             │   │   CODE EXECUTION SERVICE (isolated) │
│  users/students/admins/events  │   │  - Separate service/host            │
│  questions/attempts/answers    │   │  - Runs in ephemeral, network-      │
│  violations/results/audit_logs │   │    isolated Docker/Firecracker      │
└────────────────────────────────┘   │    containers per submission        │
                                      │  - CPU/memory/time/pids limits      │
                                      │  - Returns stdout/stderr/verdict    │
                                      │  - Main server re-validates score   │
                                      └──────────────────────────────────────┘
```

Key principle: **the client is never trusted**. Timers, scores, and violation
counts are authoritative only on the server. The client displays state and
sends events/answers; the server recomputes everything that matters for
grading and ranking.

## 2. Tech Stack

- Next.js 14 (App Router) + React 18 + TypeScript
- Tailwind CSS
- PostgreSQL + Prisma ORM
- Auth: credentials-based login, bcrypt password hashing, JWT (httpOnly,
  SameSite=strict cookies), separate session types for `student` and `admin`
- Monaco Editor for the code editor
- Real-time: Server-Sent Events (SSE) for live monitoring (simpler and more
  firewall-friendly than WebSockets for a campus LAN; can upgrade to WS later)
- Code execution: isolated microservice (Phase 5), never the main server

## 3. Folder Structure

```
rljit-platform/
├── docs/
│   └── ARCHITECTURE.md
├── prisma/
│   ├── schema.prisma
│   └── seed.ts
├── src/
│   ├── app/
│   │   ├── layout.tsx
│   │   ├── globals.css
│   │   ├── page.tsx                       # landing / role picker
│   │   ├── (student)/
│   │   │   └── student/
│   │   │       ├── login/page.tsx
│   │   │       ├── dashboard/page.tsx     # event info + Start Test
│   │   │       └── test/[attemptId]/page.tsx
│   │   ├── (admin)/
│   │   │   └── admin/
│   │   │       ├── login/page.tsx
│   │   │       ├── dashboard/page.tsx
│   │   │       ├── events/page.tsx
│   │   │       ├── events/[eventId]/page.tsx
│   │   │       ├── events/[eventId]/questions/page.tsx
│   │   │       ├── events/[eventId]/students/page.tsx
│   │   │       ├── events/[eventId]/monitor/page.tsx
│   │   │       └── events/[eventId]/results/page.tsx
│   │   └── api/
│   │       ├── auth/
│   │       │   ├── student/login/route.ts
│   │       │   ├── admin/login/route.ts
│   │       │   └── logout/route.ts
│   │       ├── events/route.ts
│   │       ├── events/[id]/route.ts
│   │       ├── events/[id]/publish/route.ts
│   │       ├── events/[id]/code/route.ts        # generate access code
│   │       ├── questions/route.ts
│   │       ├── questions/[id]/route.ts
│   │       ├── students/route.ts
│   │       ├── students/import/route.ts
│   │       ├── attempts/start/route.ts
│   │       ├── attempts/[id]/answer/route.ts
│   │       ├── attempts/[id]/submit/route.ts
│   │       ├── attempts/[id]/heartbeat/route.ts
│   │       ├── violations/route.ts
│   │       ├── code/run/route.ts                # proxies to judge service
│   │       ├── code/submit/route.ts
│   │       ├── results/[eventId]/route.ts
│   │       ├── results/[eventId]/export/route.ts
│   │       └── monitor/[eventId]/stream/route.ts  # SSE
│   ├── components/
│   │   ├── student/  (TestShell, Timer, QuestionNav, McqQuestion, CodeQuestion, ...)
│   │   └── admin/    (StatCard, LiveTable, EventForm, QuestionForm, ...)
│   ├── lib/
│   │   ├── db.ts             # Prisma client singleton
│   │   ├── auth.ts           # JWT sign/verify, session helpers
│   │   ├── hash.ts           # bcrypt wrappers
│   │   ├── rateLimit.ts      # simple token-bucket limiter
│   │   ├── audit.ts          # audit log writer
│   │   ├── scoring.ts        # server-side scoring & ranking
│   │   └── validation.ts     # zod schemas for API input
│   ├── middleware.ts         # route protection (admin/student split)
│   └── types/
│       └── index.ts
├── judge-service/            # SEPARATE deployable, Phase 5
│   ├── src/
│   └── Dockerfile
├── .env.example
├── package.json
├── tsconfig.json
├── tailwind.config.ts
└── next.config.js
```

## 4. Database Schema (PostgreSQL, via Prisma)

Full schema lives in `prisma/schema.prisma`. Summary of tables and
relationships:

- **users** — base identity row (id, email, passwordHash, role
  [`ADMIN`|`STUDENT`], isActive, timestamps). `students` and `admins` both
  point back to `users` 1:1. Centralizing auth here keeps login logic
  uniform across roles while `students`/`admins` hold role-specific fields.
- **students** — usn (unique), name, semester, section, userId (FK →
  users).
- **admins** — name, department, userId (FK → users).
- **events** — name, department, description, startAt, endAt, durationMins,
  venue, eligible semesters (int[]), accessCode (unique, hashed), status
  (`DRAFT`|`PUBLISHED`|`ACTIVE`|`CLOSED`), config JSON (negative marking,
  violation limit, randomize flags, show leaderboard/results, etc.),
  createdBy (FK → admins).
- **questions** — eventId (FK), type (`MCQ`|`MULTI_SELECT`|`NUMERICAL`|
  `CODING`), text, marks, negativeMarks, difficulty, category, order,
  createdBy.
- **question_options** — questionId (FK), text, isCorrect, order. Used for
  MCQ/MULTI_SELECT.
- **coding_questions** — questionId (FK, 1:1), starterCode JSON (per
  language), allowedLanguages (string[]), timeLimitMs, memoryLimitMb,
  numericalAnswer (nullable, for numerical type reuse is avoided —
  numerical answers stored directly on `questions.numericalAnswer` instead;
  this table is coding-only).
- **test_cases** — codingQuestionId (FK), input, expectedOutput, isSample
  (bool, shown to student), weight (marks share), orderIndex.
- **registrations** — eventId (FK), studentId (FK), registeredAt, status
  (`REGISTERED`|`DISABLED`). Unique (eventId, studentId).
- **attempts** — eventId (FK), studentId (FK), status (`NOT_STARTED`|
  `ACTIVE`|`WARNING`|`SUBMITTED`|`AUTO_SUBMITTED`|`EXPIRED`), startedAt,
  submittedAt, serverDeadline (computed at start = startedAt + duration,
  authoritative for auto-submit), lastActivityAt, violationCount, score
  (nullable until graded), rank (nullable). Unique (eventId, studentId) —
  enforces "no multiple active attempts."
- **answers** — attemptId (FK), questionId (FK), selectedOptionIds
  (int[]/json for MCQ/multi), numericalValue, codeSubmission (text),
  language, isCorrect (nullable), marksAwarded, updatedAt. Unique
  (attemptId, questionId) — upsert on autosave.
- **submissions** — answerId (FK), a log of each "Run Code"/"Submit Code"
  call for coding questions: sourceCode, language, verdict
  (`ACCEPTED`|`WRONG_ANSWER`|`TLE`|`RUNTIME_ERROR`|`COMPILE_ERROR`),
  testCasesPassed, testCasesTotal, runtimeMs, memoryKb, createdAt. Kept
  separate from `answers` so every run is auditable, while `answers` holds
  only the final/best submission used for scoring.
- **violations** — attemptId (FK), studentId (FK), eventId (FK), type
  (`TAB_SWITCH`|`WINDOW_BLUR`|`FULLSCREEN_EXIT`|`COPY_ATTEMPT`|
  `PASTE_ATTEMPT`|`RIGHT_CLICK`), timestamp, metadata JSON.
- **results** — denormalized, generated after grading: attemptId (FK,
  unique), eventId (FK), studentId (FK), totalScore, completionTimeSecs,
  rank, isReleased (bool — faculty can hold back results). Kept separate
  from `attempts` so re-ranking/export doesn't touch live attempt state.
- **audit_logs** — actorId (FK → users, nullable for system actions),
  action (string, e.g. `EVENT_PUBLISHED`, `STUDENT_DISABLED`,
  `RESULTS_RELEASED`), targetType, targetId, metadata JSON, ipAddress,
  createdAt.

### Indexes (beyond PKs/FKs)
- `students.usn` unique
- `users.email` unique
- `events.accessCode` unique
- `attempts (eventId, studentId)` unique; `attempts (eventId, status)` for
  live monitoring queries
- `answers (attemptId, questionId)` unique
- `violations (attemptId)`, `violations (eventId, type)`
- `results (eventId, totalScore DESC, completionTimeSecs ASC)` — supports
  the ranking query directly

### Ranking / tie-break rule (documented, enforced server-side only)
1. Higher `totalScore` first.
2. If equal, lower `completionTimeSecs` (submittedAt − startedAt) first.
3. If still equal, earlier `submittedAt` timestamp wins (stable, deterministic
   final tiebreaker so ranks are never ambiguous or order-dependent).

### Migration strategy
- Prisma Migrate (`prisma migrate dev` locally, `prisma migrate deploy` in
  CI/CD) — every schema change is a checked-in, reviewable SQL migration
  file under `prisma/migrations/`.
- Seed script (`prisma/seed.ts`) creates a default admin account and a
  sample event for local development.
- No destructive migrations against production without a reviewed
  migration PR and a backup snapshot step in CI.

## 5. API Specification (high level)

All routes under `/api`. All admin routes require an admin session; all
student routes require a student session; auth is enforced in
`middleware.ts` and re-checked per-handler (defense in depth). Every
mutating admin action writes an `audit_logs` row.

| Method | Route | Purpose | Auth |
|---|---|---|---|
| POST | /api/auth/student/login | USN/email + password or event access code | public |
| POST | /api/auth/admin/login | email + password | public |
| POST | /api/auth/logout | clear session cookie | any |
| GET/POST | /api/events | list / create events | admin |
| GET/PUT/DELETE | /api/events/:id | read / update / delete event | admin |
| POST | /api/events/:id/publish | publish + generate access code | admin |
| POST | /api/questions | add question (+ options/test cases) | admin |
| GET/PUT/DELETE | /api/questions/:id | manage a question | admin |
| POST | /api/students | add a student | admin |
| POST | /api/students/import | CSV bulk import | admin |
| POST | /api/attempts/start | begin/resume an attempt (idempotent) | student |
| POST | /api/attempts/:id/answer | autosave one answer | student |
| POST | /api/attempts/:id/submit | final submit, triggers grading | student |
| POST | /api/attempts/:id/heartbeat | liveness + server clock sync | student |
| POST | /api/violations | log a monitoring violation | student |
| POST | /api/code/run | run against sample test cases (proxied to judge) | student |
| POST | /api/code/submit | run against all test cases, score | student |
| GET | /api/results/:eventId | ranked results (respects release flag) | admin, student(own) |
| GET | /api/results/:eventId/export | CSV/XLSX/PDF export | admin |
| GET | /api/monitor/:eventId/stream | SSE stream of live attempt state | admin |

## 6. UI Page Map

**Student**
`/student/login` → `/student/dashboard` (event info, instructions, Start
Test) → `/student/test/[attemptId]` (fullscreen test shell: timer,
question nav, answer area, save/next/prev/submit, violation warnings) →
post-submit confirmation screen.

**Admin**
`/admin/login` → `/admin/dashboard` (stat cards, event list) →
`/admin/events/[id]` (edit event/config) →
`/admin/events/[id]/questions` (question bank CRUD) →
`/admin/events/[id]/students` (registration, CSV import, enable/disable) →
`/admin/events/[id]/monitor` (live table, SSE-driven) →
`/admin/events/[id]/results` (ranked table, filters, export, release
toggle).

## 7. Security Model (summary; detailed in Phase 1/6/9)

- Passwords hashed with bcrypt (cost 12). Never logged or returned in API
  responses.
- JWT session in httpOnly, Secure, SameSite=strict cookies; short-lived
  access token + rotation on privileged actions.
- `middleware.ts` gates every `/admin/*` page and `/api/*` admin route by
  role; student routes similarly gated and further scoped so a student can
  only touch their own `attempts`/`answers`/`violations` rows (ownership
  check in every handler, not just role check).
- All scoring and timer-expiry logic is recomputed server-side from
  `attempts.serverDeadline` and stored answers — the client's displayed
  timer and any client-computed score are informational only.
- Rate limiting on login and answer-autosave endpoints.
- Student-submitted code is **never** executed in the Next.js process; it
  is sent to the isolated judge service over an authenticated internal
  channel, run in a throwaway sandboxed container with strict CPU/memory/
  time/network limits, and only the verdict + stdout/stderr come back.

---
This document is the reference for all phases. Phase 1 below implements
the schema, project scaffold, and authentication.
