import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const db = new PrismaClient();

async function main() {
  const adminPasswordHash = await bcrypt.hash("ChangeMe@123", 12);
  const adminUser = await db.user.upsert({
    where: { email: "admin@rljit.edu" },
    update: {},
    create: {
      email: "admin@rljit.edu",
      passwordHash: adminPasswordHash,
      role: "ADMIN",
      admin: {
        create: {
          name: "CSE Department Admin",
          department: "Department of Computer Science and Engineering",
        },
      },
    },
  });
  console.log("Seeded admin:", adminUser.email, "(password: ChangeMe@123)");

  const studentPasswordHash = await bcrypt.hash("Student@123", 12);
  const studentUser = await db.user.upsert({
    where: { email: "1rj23cs001@rljit.edu" },
    update: {},
    create: {
      email: "1rj23cs001@rljit.edu",
      passwordHash: studentPasswordHash,
      role: "STUDENT",
      student: {
        create: {
          usn: "1RJ23CS001",
          name: "Sample Student",
          semester: 5,
          section: "A",
        },
      },
    },
  });
  console.log(
    "Seeded student:",
    studentUser.email,
    "USN 1RJ23CS001 (password: Student@123)"
  );
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
